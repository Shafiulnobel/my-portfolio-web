<section style="background-color: #000000" class="intro">
        <div class="container">
          <div class="row">
            <div class="col text-center order-md-1">
              <img
                style="width: 20rem"
                src="https://i.ibb.co/BKxZwMc/nobel.png"
                alt="image"
              />
            </div>
            <div class="col text-start d-flex align-items-center order-md-1">
              <div>
                <h1 class="fw-bold text-light">
                  Hello <span class="text-danger">!</span>
                </h1>
                <h5 class="text-light">I'm Shafiul Islam Nobel</h5>
                <h5 class="text-light">
                  A filmmaker, photographer & content creator
                  <span class="text-danger fw-bold">.</span>
                </h5>
              </div>
            </div>
          </div>
        </div>
      </section>
