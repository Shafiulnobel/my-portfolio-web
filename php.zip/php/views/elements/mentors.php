<section class="Mentors">
        <div class="container">
          <h1 class="text-center text-light pt-5">MENTORS</h1>
          <div class="row pt-5">
            <div class="col-12 col-md-4 text-center">
              <img
                style="width: 10rem"
                class="rounded-circle"
                src="images/jubaer.jpg"
                alt="img1"
              />
              <h3 class="text-light">Jubaer Talukder</h3>
              <p class="text-light">Filmmaker</p>
            </div>
            <div class="col-12 col-md-4 text-center">
              <img
                style="width: 10rem"
                class="rounded-circle"
                src="images/peter.jpg"
                alt="img1"
              />
              <h3 class="text-light">Peter Mckinnon</h3>
              <p class="text-light">Content Creator</p>
            </div>
            <div class="col-12 col-md-4 text-center">
              <img
                style="width: 10rem"
                class="rounded-circle"
                src="images/daniel.jpg"
                alt="img1"
              />
              <h3 class="text-light">Daniel Schiffer</h3>
              <p class="text-light">Content Creator</p>
            </div>
          </div>
        </div>
      </section>
