<footer class="pb-3 pt-3" style="background-color: #2f2e2e">
      <div class="container d-flex justify-content-center">
        <img width="62rem" src="images/logo.png" alt="">
      </div>
      <p class="text-light text-center mb-0">shafiulislamnobel@gmail.com</p>
      <p class="text-light text-center">©2023 by Shafiul Islam Nobel. </p>

    </footer>