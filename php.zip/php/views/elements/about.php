<section class="About pt-5">
        <div class="container">
          <div class="row">
            <div class="col">
              <h1 class="text-light text-center">ABOUT ME</h1>
              <div class="d-flex justify-content-center">
                <p class="w-50 text-start text-light">
                  Lorem ipsum dolor sit amet consectetur adipisicing elit.
                  Eveniet, veritatis tenetur reprehenderit mollitia perferendis
                  ipsa id hic possimus! Temporibus doloribus, architecto quaerat
                  culpa eos cum molestiae harum nemo placeat incidunt mollitia?
                  Adipisci inventore porro incidunt! Cupiditate, hic. Cumque
                  suscipit, itaque obcaecati ex voluptatem iure est blanditiis
                  reiciendis eaque consectetur pariatur.
                </p>
              </div>
              <div class="text-center link">
                <button
                  style="background-color: #dc1b20; border-radius: 0"
                  type="button"
                  class="btn border border-0"
                >
                  <a class="text-decoration-none text-light" href="#"
                    >Read More <i class="fa-solid fa-chevron-right"></i
                  ></a>
                </button>
              </div>
              <div class="row pt-5 text-center">
                <div class="col link">
                  <a
                    class="text-light fs-5"
                    href="https://www.facebook.com/Nobel1234/videos/913804583062774"
                    target="_blank"
                  >
                    <i style="color: #7e1316" class="fa-solid fa-link"></i
                    >intro</a
                  >
                </div>
                <div class="col link">
                  <a
                    class="text-light fs-5"
                    href="https://www.youtube.com/watch?v=XpERtI5OtiY"
                    target="_blank"
                    ><i style="color: #7e1316" class="fa-solid fa-link"></i>
                    Top 6
                  </a>
                </div>
                <div class="col link">
                  <a
                    class="text-light fs-5"
                    href="https://youtu.be/vsw-SsljHJ0"
                    target="_blank"
                    ><i style="color: #7e1316" class="fa-solid fa-link"></i>Most
                    View</a
                  >
                </div>
              </div>
            </div>
            <div class="col">
              <img
                style="width: 24.5rem"
                src="https://i.ibb.co/2ZzWnWB/nobel-1.jpg"
                alt="about-img"
              />
            </div>
          </div>
        </div>
      </section>