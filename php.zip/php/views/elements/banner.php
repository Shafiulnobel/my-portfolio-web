<section class="banner">
        <img class="w-100" src="images/cover.jpg" alt="img" />
      </section>
