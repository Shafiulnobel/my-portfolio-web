<section
        class="social-media w-100"
        style="background-color: #000000; overflow: hidden"
      >
        <h1 class="text-center text-light">FIND ME ON SOCIALS</h1>

        <div class="row">
          <div
            style="background-color: #e21c21"
            class="col col-md-3 text-center pt-5 pb-5 text-light"
          >
            <a
              style="text-decoration: none; color: antiquewhite"
              href="https://www.youtube.com/@filmbynobel1685"
              target="_blank"
              ><i style="font-size: 5rem" class="fa-brands fa-youtube"></i
            ></a>
            <div class="link">
              <a
                target="_blank"
                class="text-light"
                href="https://www.youtube.com/@filmbynobel1685"
                >Find me on youtube</a
              >
            </div>
          </div>
          <div class="col col-md-3 text-center pt-5 pb-5 bg-primary text-light">
            <a
              style="text-decoration: none; color: antiquewhite"
              href="https://www.facebook.com/Nobel1234/"
              target="_blank"
              ><i style="font-size: 5rem" class="fa-brands fa-facebook-f"></i
            ></a>
            <div class="link">
              <a
                target="_blank"
                class="text-light"
                href="https://www.facebook.com/Nobel1234/"
                >Find me on facebook</a
              >
            </div>
          </div>
          <div class="col col-md-3 text-center pt-5 pb-5 bg-danger text-light">
            <a
              style="text-decoration: none; color: antiquewhite"
              href="https://www.instagram.com/shafiul_nobel/"
              target="_blank"
              ><i style="font-size: 5rem" class="fa-brands fa-instagram"></i
            ></a>
            <div class="link">
              <a
                target="_blank"
                class="text-light"
                href="https://www.instagram.com/shafiul_nobel/"
                >Find me on instagram</a
              >
            </div>
          </div>
          <div class="col col-md-3 text-center pt-5 pb-5 bg-info text-light">
            <a
              style="text-decoration: none; color: antiquewhite"
              href="https://www.linkedin.com/in/shafiul-islam-nobel-0612141a4/"
              target="_blank"
              ><i
                style="font-size: 5rem"
                <i
                class="fa-brands fa-linkedin-in"
              ></i
            ></a>
            <div class="link">
              <a
                target="_blank"
                class="text-light"
                href="https://www.instagram.com/shafiul_nobel/"
                >Find me on linkedin</a
              >
            </div>
          </div>
        </div>
      </section>