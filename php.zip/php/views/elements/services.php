<section class="services pt-5 pb-5">
        <h1 class="text-center text-light">SERVICES</h1>
        <div class="container text-center pt-5 pb-5">
          <div class="row">
            <div class="col-12 col-lg-4">
              <div>
                <a href="#" target="_blank"
                  ><i
                    style="font-size: 4rem"
                    class="fa-solid fa-camera text-light"
                  ></i
                ></a>
              </div>
              <h3 class="text-light">Photography</h3>
            </div>
            <div class="col-12 col-md-6 col-lg-4">
              <div>
                <a href="#" target="_blank"
                  ><i
                    style="font-size: 4rem"
                    class="fa-solid fa-film text-light"
                  ></i
                ></a>
              </div>
              <h3 class="text-light">Product Commercial</h3>
            </div>
            <div class="col-12 col-md-6 col-lg-4">
              <div>
                <a href="#" target="_blank"
                  ><i
                    style="font-size: 4rem"
                    class="fa-solid fa-pen-nib text-light"
                  ></i>
                </a>
              </div>
              <h3 class="text-light">Thumbnail Design</h3>
            </div>
          </div>
        </div>
      </section>