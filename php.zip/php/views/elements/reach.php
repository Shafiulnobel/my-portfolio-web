<section class="text-light pt-5 pb-5">
        <div class="container text-center" class="reach">
          <div class="row row-cols-1 row-cols-lg-4 row-cols-md-4 g-2 g-lg-3">
            <div class="col">
              <div class="p-3">
                <h1
                  style="color: #dc1b20; font-size: 4.5rem"
                  class="fw-bold mb-0"
                >
                  50+
                </h1>
                <h3>Videos</h3>
              </div>
            </div>
            <div class="col">
              <div class="p-3">
                <h1
                  style="color: #dc1b20; font-size: 4.5rem"
                  class="fw-bold mb-0"
                >
                  40k+
                </h1>
                <h3>Views</h3>
              </div>
            </div>
            <div class="col">
              <div class="p-3">
                <h1
                  style="color: #dc1b20; font-size: 4.5rem"
                  class="fw-bold mb-0"
                >
                  150+
                </h1>
                <h3>Subscriber</h3>
              </div>
            </div>
            <div class="col">
              <div class="p-3">
                <h1
                  style="color: #dc1b20; font-size: 4.5rem"
                  class="fw-bold mb-0"
                >
                  10+
                </h1>
                <h3>Ideas</h3>
              </div>
            </div>
          </div>
        </div>
      </section>
